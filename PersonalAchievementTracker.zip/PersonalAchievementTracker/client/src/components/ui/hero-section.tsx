import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function HeroSection() {
  const [isVisible, setIsVisible] = useState(false);
  const [currentStatistic, setCurrentStatistic] = useState(0);
  
  const statistics = [
    { value: "50,000+", label: "Crypto Enthusiasts" },
    { value: "200+", label: "Verified Airdrops" },
    { value: "$2.5M+", label: "User Rewards Claimed" },
    { value: "24/7", label: "Expert Support" }
  ];

  useEffect(() => {
    setIsVisible(true);
    
    // Rotate statistics every 3 seconds
    const interval = setInterval(() => {
      setCurrentStatistic((prev) => (prev + 1) % statistics.length);
    }, 3000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="hero-bg p-8 md:p-12 lg:p-16 rounded-b-2xl relative overflow-hidden">
      {/* Animated background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
        <div className="absolute inset-0 opacity-30 mix-blend-overlay">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice">
            <defs>
              <radialGradient id="Gradient1" cx="50%" cy="50%" fx="0.441602%" fy="50%" r=".5">
                <animate attributeName="fx" dur="25s" values="0%;3%;0%" repeatCount="indefinite"></animate>
                <stop offset="0%" stopColor="rgba(59, 130, 246, 0.5)"></stop>
                <stop offset="100%" stopColor="rgba(59, 130, 246, 0)"></stop>
              </radialGradient>
              <radialGradient id="Gradient2" cx="50%" cy="50%" fx="2.68147%" fy="50%" r=".5">
                <animate attributeName="fx" dur="23s" values="0%;5%;0%" repeatCount="indefinite"></animate>
                <stop offset="0%" stopColor="rgba(139, 92, 246, 0.5)"></stop>
                <stop offset="100%" stopColor="rgba(139, 92, 246, 0)"></stop>
              </radialGradient>
              <radialGradient id="Gradient3" cx="50%" cy="50%" fx="0.836536%" fy="50%" r=".5">
                <animate attributeName="fx" dur="21s" values="0%;8%;0%" repeatCount="indefinite"></animate>
                <stop offset="0%" stopColor="rgba(236, 72, 153, 0.5)"></stop>
                <stop offset="100%" stopColor="rgba(236, 72, 153, 0)"></stop>
              </radialGradient>
            </defs>
            <rect x="0" y="0" width="100%" height="100%" fill="url(#Gradient1)">
              <animate attributeName="x" dur="20s" values="0%;25%;0%" repeatCount="indefinite"></animate>
              <animate attributeName="y" dur="21s" values="0%;25%;0%" repeatCount="indefinite"></animate>
            </rect>
            <rect x="0" y="0" width="100%" height="100%" fill="url(#Gradient2)">
              <animate attributeName="x" dur="22s" values="0%;-25%;0%" repeatCount="indefinite"></animate>
              <animate attributeName="y" dur="24s" values="0%;-25%;0%" repeatCount="indefinite"></animate>
            </rect>
            <rect x="0" y="0" width="100%" height="100%" fill="url(#Gradient3)">
              <animate attributeName="x" dur="23s" values="0%;-25%;0%" repeatCount="indefinite"></animate>
              <animate attributeName="y" dur="24s" values="0%;25%;0%" repeatCount="indefinite"></animate>
            </rect>
          </svg>
        </div>
      </div>
      
      {/* Animated floating particles */}
      <div className="absolute inset-0 overflow-hidden">
        {Array.from({ length: 12 }).map((_, i) => (
          <div 
            key={i}
            className="absolute rounded-full mix-blend-screen" 
            style={{
              width: `${Math.random() * 20 + 5}px`,
              height: `${Math.random() * 20 + 5}px`,
              backgroundColor: `rgba(${Math.random() * 100 + 100}, ${Math.random() * 100 + 100}, ${Math.random() * 255}, 0.${Math.floor(Math.random() * 4) + 2})`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${Math.random() * 10 + 10}s linear infinite`,
              animationDelay: `${Math.random() * 5}s`
            }}
          />
        ))}
      </div>
      
      {/* Glowing orbs */}
      <div className="absolute w-72 h-72 bg-blue-500/10 rounded-full blur-3xl top-10 -left-20 animate-pulse"></div>
      <div className="absolute w-72 h-72 bg-purple-500/10 rounded-full blur-3xl bottom-10 -right-20 animate-pulse" style={{ animationDelay: "1s" }}></div>
      <div className="absolute w-96 h-96 bg-pink-500/10 rounded-full blur-3xl -bottom-20 left-1/3 animate-pulse" style={{ animationDelay: "2s" }}></div>
      
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          <motion.div 
            className="lg:w-1/2 mb-8 lg:mb-0"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : 30 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="inline-block bg-gradient-to-r from-blue-600 to-purple-600 text-white text-sm font-medium px-4 py-1.5 rounded-full mb-4"
            >
              The Ultimate Crypto Airdrop Platform
            </motion.div>
            
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold mb-6 text-white leading-tight">
              Discover & Claim <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500">Crypto Airdrops</span> Worth Real Value
            </h1>
            
            <p className="text-gray-300 mb-8 text-lg md:text-xl max-w-2xl">
              Get comprehensive step-by-step guides to claim airdrops, participate in testnets, and earn substantial rewards from the most promising crypto projects.
            </p>
            
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 mb-8">
              <Link to="/airdrops">
                <Button size="lg" className="w-full sm:w-auto bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-700 hover:via-indigo-700 hover:to-purple-700 shadow-xl hover:shadow-blue-500/20 transition-all duration-300 text-base">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13l-3 3m0 0l-3-3m3 3V8m0 13a9 9 0 110-18 9 9 0 010 18z" />
                  </svg>
                  Explore Airdrops
                </Button>
              </Link>
              <Button variant="outline" size="lg" className="w-full sm:w-auto border border-gray-600 hover:bg-gray-800/50 transition-all duration-300 text-base backdrop-blur-sm">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                How It Works
              </Button>
            </div>
            
            {/* Animated statistics */}
            <div className="p-3 bg-gray-800/30 backdrop-blur-sm rounded-xl border border-gray-700/50 shadow-lg">
              <div className="flex items-center space-x-3">
                <div className="p-3 bg-blue-500/10 rounded-lg">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                </div>
                <div>
                  <div className="text-gray-400 text-sm font-medium">Trusted by crypto enthusiasts</div>
                  <div className="h-7 overflow-hidden">
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={currentStatistic}
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        exit={{ y: -20, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="flex items-baseline"
                      >
                        <span className="text-xl font-bold text-white mr-2">{statistics[currentStatistic].value}</span>
                        <span className="text-sm text-gray-400">{statistics[currentStatistic].label}</span>
                      </motion.div>
                    </AnimatePresence>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            className="lg:w-1/2 flex justify-center"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: isVisible ? 1 : 0, scale: isVisible ? 1 : 0.95 }}
            transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
          >
            {/* Enhanced Interactive crypto illustration */}
            <div className="relative max-w-full">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-gray-800/50 backdrop-blur-md">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="540"
                  height="400"
                  viewBox="0 0 540 400"
                  fill="none"
                  className="rounded-2xl max-w-full h-auto"
                >
                  <rect width="540" height="400" rx="24" fill="url(#gradBg)" />
                  <defs>
                    <linearGradient id="gradBg" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#0f172a" />
                      <stop offset="100%" stopColor="#1e293b" />
                    </linearGradient>
                  </defs>
                  
                  {/* Grid pattern */}
                  <pattern id="grid" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
                    <rect width="40" height="40" fill="none" />
                    <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e2a45" strokeWidth="1" opacity="0.3" />
                  </pattern>
                  <rect x="0" y="0" width="540" height="400" fill="url(#grid)" />
                  
                  {/* Enhanced blockchain network */}
                  <circle cx="270" cy="200" r="150" fill="url(#networkGlow)" />
                  <defs>
                    <radialGradient id="networkGlow" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
                      <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.05" />
                      <stop offset="100%" stopColor="#1e293b" stopOpacity="0" />
                    </radialGradient>
                  </defs>
                  
                  {/* Network lines */}
                  <g opacity="0.3">
                    {Array.from({ length: 8 }).map((_, i) => (
                      <line 
                        key={i}
                        x1="270" 
                        y1="200" 
                        x2={270 + 150 * Math.cos(2 * Math.PI * i / 8)} 
                        y2={200 + 150 * Math.sin(2 * Math.PI * i / 8)} 
                        stroke="#3b82f6" 
                        strokeWidth="1"
                        strokeDasharray="4 4"
                      >
                        <animate attributeName="opacity" values="0.2;0.6;0.2" dur={`${3 + i % 3}s`} repeatCount="indefinite" />
                      </line>
                    ))}
                  </g>
                  
                  {/* Central hub */}
                  <circle cx="270" cy="200" r="20" fill="#3b82f6">
                    <animate attributeName="r" values="20;22;20" dur="3s" repeatCount="indefinite" />
                    <animate attributeName="opacity" values="0.8;1;0.8" dur="3s" repeatCount="indefinite" />
                  </circle>
                  <circle cx="270" cy="200" r="10" fill="#ffffff" opacity="0.5" />
                  
                  {/* Orbital nodes */}
                  {Array.from({ length: 8 }).map((_, i) => {
                    const angle = (2 * Math.PI * i) / 8;
                    const radius = 130;
                    const x = 270 + radius * Math.cos(angle);
                    const y = 200 + radius * Math.sin(angle);
                    const colors = ["#3b82f6", "#8b5cf6", "#ec4899", "#10b981", "#f59e0b", "#ef4444", "#14b8a6", "#a855f7"];
                    
                    return (
                      <g key={i}>
                        <circle cx={x} cy={y} r="12" fill={colors[i % colors.length]}>
                          <animate 
                            attributeName="opacity" 
                            values="0.7;1;0.7" 
                            dur={`${2 + i % 3}s`} 
                            repeatCount="indefinite" 
                          />
                        </circle>
                        <text x={x} y={y + 24} fontSize="10" fill="#ffffff" textAnchor="middle">
                          {["BTC", "ETH", "SOL", "AVAX", "DOT", "LINK", "ATOM", "ADA"][i]}
                        </text>
                      </g>
                    );
                  })}
                  
                  {/* Orbital paths */}
                  <circle cx="270" cy="200" r="130" stroke="#3b82f6" strokeWidth="1" strokeDasharray="4 4" fill="none" opacity="0.4" />
                  <circle cx="270" cy="200" r="85" stroke="#8b5cf6" strokeWidth="1" strokeDasharray="4 4" fill="none" opacity="0.3" />
                  
                  {/* Inner orbital nodes */}
                  {Array.from({ length: 6 }).map((_, i) => {
                    const angle = (2 * Math.PI * i) / 6 + Math.PI / 6;
                    const radius = 85;
                    const x = 270 + radius * Math.cos(angle);
                    const y = 200 + radius * Math.sin(angle);
                    const colors = ["#ec4899", "#10b981", "#f59e0b", "#ef4444", "#14b8a6", "#a855f7"];
                    
                    return (
                      <g key={i}>
                        <circle cx={x} cy={y} r="8" fill={colors[i % colors.length]}>
                          <animate 
                            attributeName="opacity" 
                            values="0.7;1;0.7" 
                            dur={`${3 + i % 2}s`} 
                            repeatCount="indefinite" 
                          />
                        </circle>
                      </g>
                    );
                  })}
                  
                  {/* Moving particles along network */}
                  {Array.from({ length: 12 }).map((_, i) => {
                    const lineIndex = i % 8;
                    const angle = (2 * Math.PI * lineIndex) / 8;
                    const colors = ["#3b82f6", "#8b5cf6", "#ec4899", "#10b981", "#f59e0b", "#ef4444", "#14b8a6", "#a855f7"];
                    
                    return (
                      <circle key={i} r="3" fill={colors[i % colors.length]}>
                        <animate 
                          attributeName="cx" 
                          values={`270;${270 + 150 * Math.cos(angle)}`}
                          dur={`${3 + i % 4}s`}
                          repeatCount="indefinite"
                          begin={`${i * 0.5}s`}
                        />
                        <animate 
                          attributeName="cy" 
                          values={`200;${200 + 150 * Math.sin(angle)}`}
                          dur={`${3 + i % 4}s`}
                          repeatCount="indefinite"
                          begin={`${i * 0.5}s`}
                        />
                        <animate 
                          attributeName="opacity" 
                          values="1;0"
                          dur={`${3 + i % 4}s`}
                          repeatCount="indefinite"
                          begin={`${i * 0.5}s`}
                        />
                      </circle>
                    );
                  })}
                  
                  {/* Airdrop symbols */}
                  <g opacity="0.9">
                    <path
                      d="M270 130 L285 145 L270 160 L255 145 Z"
                      fill="#3b82f6"
                    >
                      <animate attributeName="opacity" values="0.6;1;0.6" dur="2s" repeatCount="indefinite" />
                    </path>
                  </g>
                  
                  {/* Feature texts */}
                  <text x="120" y="70" fill="#ffffff" fontSize="12" fontWeight="bold">Verified Projects</text>
                  <text x="400" y="70" fill="#ffffff" fontSize="12" fontWeight="bold">Secure Infrastructure</text>
                  <text x="120" y="330" fill="#ffffff" fontSize="12" fontWeight="bold">Real-time Updates</text>
                  <text x="400" y="330" fill="#ffffff" fontSize="12" fontWeight="bold">Exclusive Rewards</text>
                </svg>
              </div>
              
              {/* Floating badges */}
              <div className="absolute -top-5 -right-5 bg-gradient-to-br from-blue-500 to-indigo-600 text-white px-4 py-2 rounded-lg shadow-lg font-medium text-sm flex items-center space-x-2 whitespace-nowrap animate-pulse">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
                <span>New Airdrops Daily</span>
              </div>
              
              <div className="absolute -bottom-3 left-10 bg-gradient-to-br from-green-500 to-emerald-600 text-white px-4 py-2 rounded-lg shadow-lg font-medium text-sm flex items-center space-x-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span>Verified & Safe</span>
              </div>
              
              <div className="absolute top-1/3 -right-3 bg-gradient-to-br from-purple-500 to-pink-600 text-white px-3 py-1.5 rounded-lg shadow-lg font-medium text-xs flex items-center space-x-1.5 transform rotate-6">
                <span>Featured</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
