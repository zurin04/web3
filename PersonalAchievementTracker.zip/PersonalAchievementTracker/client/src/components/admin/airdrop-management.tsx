import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Loader2, Edit, Trash, Eye } from "lucide-react";
import { Airdrops } from "@shared/schema";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { formatCurrency } from "@/lib/utils";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Link } from "wouter";

export default function AirdropManagement() {
  const { toast } = useToast();
  const [airdropToDelete, setAirdropToDelete] = useState<Airdrops | null>(null);
  
  const { data: airdrops, isLoading } = useQuery<Airdrops[]>({
    queryKey: ["/api/admin/airdrops"],
  });
  
  const deleteAirdropMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/airdrops/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Airdrop deleted",
        description: "The airdrop has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/airdrops"] });
      setAirdropToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete airdrop",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Airdrops</h2>
        <Link to="/admin/airdrops/create">
          <Button>Add New Airdrop</Button>
        </Link>
      </div>
      
      {airdrops && airdrops.length > 0 ? (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Views</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {airdrops.map((airdrop) => (
                <TableRow key={airdrop.id}>
                  <TableCell className="font-medium">
                    <div className="truncate max-w-[300px]">{airdrop.title}</div>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        airdrop.status === "active"
                          ? "default"
                          : airdrop.status === "upcoming"
                          ? "secondary"
                          : "outline"
                      }
                    >
                      {airdrop.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{formatCurrency(airdrop.views || 0)}</TableCell>
                  <TableCell className="text-right space-x-2">
                    <Button variant="outline" size="icon" asChild>
                      <Link to={`/airdrop/${airdrop.id}`}>
                        <Eye className="h-4 w-4" />
                      </Link>
                    </Button>
                    <Button variant="outline" size="icon" asChild>
                      <Link to={`/admin/airdrops/edit/${airdrop.id}`}>
                        <Edit className="h-4 w-4" />
                      </Link>
                    </Button>
                    
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="outline" size="icon" onClick={() => setAirdropToDelete(airdrop)}>
                          <Trash className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                          <AlertDialogDescription>
                            This will permanently delete the airdrop "{airdrop.title}". This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => deleteAirdropMutation.mutate(airdrop.id)}
                          >
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        <div className="text-center py-8">
          <p className="text-muted-foreground mb-4">No airdrops have been created yet.</p>
          <Link to="/admin/airdrops/create">
            <Button>Create Your First Airdrop</Button>
          </Link>
        </div>
      )}
    </div>
  );
}