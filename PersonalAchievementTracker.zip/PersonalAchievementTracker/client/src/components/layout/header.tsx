import { useState } from "react";
import { useLocation, Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Category, SiteSettings } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { Menu, User, LogOut, ChevronDown, Plus, Settings, FileText, Users } from "lucide-react";

export default function Header() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, logoutMutation } = useAuth();

  // Fetch categories for the navigation
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Fetch site settings for logo and site name
  const { data: siteSettings } = useQuery<SiteSettings>({
    queryKey: ["/api/site-settings"],
  });

  const isActive = (path: string) => {
    // Check if the path is exactly matching or if it's a category path and the current location is for that category
    if (location === path) return true;
    
    // For category paths, check if we're on a specific category page
    if (path.startsWith('/airdrops/category/') && location.startsWith('/airdrops/category/')) {
      const categoryId = path.split('/').pop();
      const currentCategoryId = location.split('/').pop();
      return categoryId === currentCategoryId;
    }
    
    return false;
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        <div className="flex items-center space-x-4">
          <Link to="/">
            <div className="flex items-center space-x-2">
              {siteSettings?.logo_url ? (
                <img 
                  src={siteSettings.logo_url} 
                  alt="Logo" 
                  className="h-8 w-auto" 
                />
              ) : (
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                  </svg>
                </div>
              )}
              <span className="text-xl font-bold hidden md:block">{siteSettings?.site_name || "AirdropHub"}</span>
            </div>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <div className="hidden md:flex md:flex-1 md:justify-center">
          <NavigationMenu>
            <NavigationMenuList>
              <NavigationMenuItem>
                <Link to="/">
                  <NavigationMenuLink className={cn(
                    navigationMenuTriggerStyle(),
                    isActive("/") && "bg-accent text-accent-foreground"
                  )}>
                    Home
                  </NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
              
              <NavigationMenuItem>
                <Link to="/airdrops">
                  <NavigationMenuLink className={cn(
                    navigationMenuTriggerStyle(),
                    isActive("/airdrops") && "bg-accent text-accent-foreground"
                  )}>
                    All Airdrops
                  </NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
              

              
              <NavigationMenuItem>
                <NavigationMenuTrigger>Categories</NavigationMenuTrigger>
                <NavigationMenuContent>
                  <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                    {categories.map((category) => (
                      <li key={category.id}>
                        <Link to={`/airdrops/category/${category.id}`}>
                          <NavigationMenuLink
                            className={cn(
                              "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
                              isActive(`/airdrops/category/${category.id}`) && "bg-accent text-accent-foreground"
                            )}
                          >
                            <div className="text-sm font-medium leading-none">{category.name}</div>
                            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                              {category.description}
                            </p>
                          </NavigationMenuLink>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </NavigationMenuContent>
              </NavigationMenuItem>
              
              {/* Creator Link */}
              {(user?.isCreator || user?.isAdmin) && (
                <NavigationMenuItem>
                  <Link to="/create-airdrop">
                    <NavigationMenuLink className={cn(
                      navigationMenuTriggerStyle(),
                      isActive("/create-airdrop") && "bg-accent text-accent-foreground",
                      "bg-primary/10 text-primary hover:bg-primary/20"
                    )}>
                      <Plus className="mr-2 h-4 w-4" />
                      Post New Airdrop
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
              )}
            </NavigationMenuList>
          </NavigationMenu>
        </div>

        {/* Auth section */}
        <div className="hidden md:flex md:items-center md:justify-end md:flex-1 md:space-x-4">
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative">
                  <User className="h-4 w-4 mr-2" />
                  <span>{user.username}</span>
                  <ChevronDown className="h-4 w-4 ml-1" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <Link to="/profile">
                  <DropdownMenuItem>
                    <User className="mr-2 h-4 w-4" />
                    <span>Profile</span>
                  </DropdownMenuItem>
                </Link>
                
                {/* Admin section */}
                {user.isAdmin && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuLabel>Admin</DropdownMenuLabel>
                    <Link to="/admin">
                      <DropdownMenuItem>
                        <Settings className="mr-2 h-4 w-4" />
                        <span>Dashboard</span>
                      </DropdownMenuItem>
                    </Link>
                    <Link to="/admin/creator-applications">
                      <DropdownMenuItem>
                        <FileText className="mr-2 h-4 w-4" />
                        <span>Creator Applications</span>
                      </DropdownMenuItem>
                    </Link>
                    <Link to="/admin/members">
                      <DropdownMenuItem>
                        <Users className="mr-2 h-4 w-4" />
                        <span>Members</span>
                      </DropdownMenuItem>
                    </Link>
                  </>
                )}
                
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Logout</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Link to="/auth">
              <Button>Login / Register</Button>
            </Link>
          )}
        </div>

        {/* Mobile menu button */}
        <div className="flex md:hidden ml-auto">
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-64">
              <div className="flex flex-col space-y-6 py-4">
                <div className="px-4">
                  <h2 className="text-lg font-semibold">Menu</h2>
                </div>
                <nav className="flex flex-col space-y-1">
                  <Link to="/" onClick={() => setMobileMenuOpen(false)}>
                    <div className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${isActive("/") ? "bg-primary text-white" : "hover:bg-accent"}`}>
                      <span>Home</span>
                    </div>
                  </Link>
                  <Link to="/airdrops" onClick={() => setMobileMenuOpen(false)}>
                    <div className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${isActive("/airdrops") ? "bg-primary text-white" : "hover:bg-accent"}`}>
                      <span>All Airdrops</span>
                    </div>
                  </Link>
                  
                  {/* Mobile Categories */}
                  <div className="px-4 py-2">
                    <h3 className="text-sm font-medium mb-2">Categories</h3>
                    <div className="pl-2 space-y-1">
                      {categories.map(category => (
                        <Link
                          key={category.id}
                          to={`/airdrops/category/${category.id}`}
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          <div className={`py-1 px-2 rounded-md text-sm ${
                            isActive(`/airdrops/category/${category.id}`) 
                              ? "bg-primary text-white" 
                              : "hover:bg-accent"
                          }`}>
                            {category.name}
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                  
                  {/* Creator Link on Mobile */}
                  {(user?.isCreator || user?.isAdmin) && (
                    <>
                      <div className="h-px bg-border my-2"></div>
                      <Link to="/create-airdrop" onClick={() => setMobileMenuOpen(false)}>
                        <div className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${isActive("/create-airdrop") ? "bg-primary text-white" : "hover:bg-accent"}`}>
                          <Plus className="h-4 w-4" />
                          <span>Post New Airdrop</span>
                        </div>
                      </Link>
                    </>
                  )}
                  
                  {/* Admin Links on Mobile */}
                  {user?.isAdmin && (
                    <>
                      <div className="h-px bg-border my-2"></div>
                      <div className="px-4 py-1">
                        <h3 className="text-sm font-medium">Admin</h3>
                      </div>
                      <Link to="/admin" onClick={() => setMobileMenuOpen(false)}>
                        <div className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${isActive("/admin") ? "bg-primary text-white" : "hover:bg-accent"}`}>
                          <Settings className="h-4 w-4" />
                          <span>Dashboard</span>
                        </div>
                      </Link>
                      <Link to="/admin/creator-applications" onClick={() => setMobileMenuOpen(false)}>
                        <div className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${isActive("/admin/creator-applications") ? "bg-primary text-white" : "hover:bg-accent"}`}>
                          <FileText className="h-4 w-4" />
                          <span>Creator Applications</span>
                        </div>
                      </Link>
                      <Link to="/admin/members" onClick={() => setMobileMenuOpen(false)}>
                        <div className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${isActive("/admin/members") ? "bg-primary text-white" : "hover:bg-accent"}`}>
                          <Users className="h-4 w-4" />
                          <span>Members</span>
                        </div>
                      </Link>
                    </>
                  )}
                  
                  {/* User Profile or Login */}
                  <div className="h-px bg-border my-2"></div>
                  {user ? (
                    <>
                      <Link to="/profile" onClick={() => setMobileMenuOpen(false)}>
                        <div className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${isActive("/profile") ? "bg-primary text-white" : "hover:bg-accent"}`}>
                          <User className="h-4 w-4" />
                          <span>Profile</span>
                        </div>
                      </Link>
                      <button 
                        className="flex items-center space-x-2 px-4 py-2 rounded-lg text-left w-full hover:bg-accent"
                        onClick={() => {
                          handleLogout();
                          setMobileMenuOpen(false);
                        }}
                      >
                        <LogOut className="h-4 w-4" />
                        <span>Logout</span>
                      </button>
                    </>
                  ) : (
                    <Link to="/auth" onClick={() => setMobileMenuOpen(false)}>
                      <div className="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-accent">
                        <span>Login / Register</span>
                      </div>
                    </Link>
                  )}
                </nav>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}