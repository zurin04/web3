import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Helmet } from "react-helmet";
import LegalHeader from "@/components/layout/legal-header";

export default function TermsOfService() {
  return (
    <>
      <Helmet>
        <title>Terms of Service | AirdropVerse</title>
        <meta name="description" content="Terms and conditions governing the use of AirdropVerse platform and services." />
      </Helmet>
      
      <LegalHeader />
      
      <div className="container py-10 max-w-4xl mx-auto">
        <Card className="border-gray-800 shadow-lg">
          <CardHeader className="border-b border-gray-800">
            <CardTitle className="text-2xl font-bold">Terms of Service</CardTitle>
          </CardHeader>
          
          <CardContent className="pt-6 prose prose-invert max-w-none">
            <p className="text-sm text-gray-400">Last updated: May 10, 2025</p>
            
            <h2>1. Agreement to Terms</h2>
            <p>
              By accessing or using AirdropVerse (the "Service"), you agree to be bound by these Terms of Service. 
              If you disagree with any part of the terms, you may not access the Service.
            </p>

            <h2>2. Eligibility</h2>
            <p>
              You must be at least 18 years old to use our Service. By using our Service, 
              you represent and warrant that you meet all eligibility requirements. 
              The Service is not available to users previously removed from the Service by us.
            </p>

            <h2>3. User Accounts</h2>
            <p>
              When you create an account with us, you must provide accurate, complete, and up-to-date information. 
              Failure to do so constitutes a breach of the Terms, which may result in termination of your account.
            </p>
            <p>
              You are responsible for safeguarding the password that you use to access the Service and for any activities 
              or actions under your password. You agree not to disclose your password to any third party. 
              You must notify us immediately upon becoming aware of any breach of security or unauthorized use of your account.
            </p>
            <p>
              You are responsible for securing your cryptocurrency wallets, private keys, and seed phrases. 
              We will never ask for your private keys or seed phrases.
            </p>

            <h2>4. User Content</h2>
            <p>
              Our Service allows you to post, link, store, share, and otherwise make available certain information, 
              text, graphics, videos, or other material. You are responsible for the content you post to the Service, 
              including its legality, reliability, and appropriateness.
            </p>
            <p>
              By posting content to the Service, you grant us the right to use, modify, publicly perform, publicly display, 
              reproduce, and distribute such content on and through the Service. 
              You retain any and all of your rights to any content you submit, post, or display and you are responsible for protecting those rights.
            </p>

            <h2>5. Airdrops and Cryptocurrency</h2>
            <h3>5.1 No Investment Advice</h3>
            <p>
              Information provided through our Service regarding cryptocurrency airdrops, tokens, or blockchain projects 
              does not constitute investment advice, financial advice, trading advice, or any other sort of advice. 
              You should conduct your own due diligence before making any investment decisions.
            </p>

            <h3>5.2 Risk Disclosure</h3>
            <p>
              Cryptocurrency investments are subject to high market risk. We are not responsible for any losses 
              you may incur as a result of participating in airdrops or investing in cryptocurrencies. 
              Always invest within your means and at your own risk.
            </p>

            <h3>5.3 Third-Party Projects</h3>
            <p>
              The airdrops listed on our platform are third-party projects. We do not endorse, guarantee, or vouch for any 
              project or their tokens. We are not responsible for any losses, damages, or issues that may arise from 
              your interaction with these third-party projects.
            </p>

            <h2>6. Prohibited Activities</h2>
            <p>You agree not to engage in any of the following activities:</p>
            <ul>
              <li>Violating any laws or regulations</li>
              <li>Impersonating another person or entity</li>
              <li>Using the Service for any illegal activity or to promote illegal activities</li>
              <li>Attempting to compromise the security of the platform</li>
              <li>Engaging in automated data collection unless explicitly permitted</li>
              <li>Interfering with or disrupting the Service or servers</li>
              <li>Selling or transferring your account to another party</li>
              <li>Using multiple accounts to abuse airdrop rewards or incentives</li>
            </ul>

            <h2>7. Intellectual Property</h2>
            <p>
              The Service and its original content, features, and functionality are and will remain the exclusive property of 
              AirdropVerse and its licensors. The Service is protected by copyright, trademark, and other laws. 
              Our trademarks and trade dress may not be used in connection with any product or service without the prior written consent.
            </p>

            <h2>8. Termination</h2>
            <p>
              We may terminate or suspend your account immediately, without prior notice or liability, for any reason whatsoever, 
              including without limitation if you breach the Terms. Upon termination, your right to use the Service will immediately cease.
            </p>

            <h2>9. Limitation of Liability</h2>
            <p>
              In no event shall AirdropVerse, nor its directors, employees, partners, agents, suppliers, or affiliates, 
              be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, 
              loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or 
              inability to access or use the Service.
            </p>

            <h2>10. Disclaimer</h2>
            <p>
              Your use of the Service is at your sole risk. The Service is provided on an "AS IS" and "AS AVAILABLE" basis. 
              The Service is provided without warranties of any kind, whether express or implied.
            </p>

            <h2>11. Governing Law</h2>
            <p>
              These Terms shall be governed and construed in accordance with the laws, without regard to its conflict of law provisions.
            </p>

            <h2>12. Changes to Terms</h2>
            <p>
              We reserve the right to modify or replace these Terms at any time. If a revision is material, we will provide at least 30 days' 
              notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.
            </p>

            <h2>13. Contact Us</h2>
            <p>
              If you have any questions about these Terms, please contact us at:<br />
              Email: legal@airdropverse.com
            </p>
          </CardContent>
        </Card>
      </div>
    </>
  );
}