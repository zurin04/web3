import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Helmet } from "react-helmet";
import LegalHeader from "@/components/layout/legal-header";

export default function PrivacyPolicy() {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | AirdropVerse</title>
        <meta name="description" content="Our commitment to protecting your privacy and personal data on AirdropVerse." />
      </Helmet>
      
      <LegalHeader />
      
      <div className="container py-10 max-w-4xl mx-auto">
        <Card className="border-gray-800 shadow-lg">
          <CardHeader className="border-b border-gray-800">
            <CardTitle className="text-2xl font-bold">Privacy Policy</CardTitle>
          </CardHeader>
          
          <CardContent className="pt-6 prose prose-invert max-w-none">
            <p className="text-sm text-gray-400">Last updated: May 10, 2025</p>
            
            <h2>1. Introduction</h2>
            <p>
              Welcome to AirdropVerse ("we," "our," or "us"). We respect your privacy and are committed to protecting your personal data. 
              This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website 
              and use our services.
            </p>

            <h2>2. Information We Collect</h2>
            <h3>2.1 Personal Information</h3>
            <p>We may collect personal information that you voluntarily provide when using our service, including but not limited to:</p>
            <ul>
              <li>Account information (username, email address, password)</li>
              <li>Profile information (display name, profile picture, social media handles)</li>
              <li>Cryptocurrency wallet addresses</li>
              <li>Communication data (messages sent through our platform)</li>
            </ul>

            <h3>2.2 Usage Data</h3>
            <p>We automatically collect certain information when you visit, use, or navigate our platform, including:</p>
            <ul>
              <li>Device and connection information (IP address, browser type, device type)</li>
              <li>Usage patterns (pages visited, time spent on pages, clicks)</li>
              <li>Cookies and similar tracking technologies</li>
            </ul>

            <h3>2.3 Blockchain Data</h3>
            <p>
              Please note that any information you submit to a public blockchain is inherently public and not subject 
              to this privacy policy. This includes cryptocurrency transactions, wallet addresses, and other on-chain activities.
            </p>

            <h2>3. How We Use Your Information</h2>
            <p>We use the information we collect for various purposes, including:</p>
            <ul>
              <li>Providing, maintaining, and improving our services</li>
              <li>Processing transactions</li>
              <li>Verifying your identity and eligibility for airdrops</li>
              <li>Communicating with you about updates, security alerts, and support</li>
              <li>Analyzing usage patterns to improve user experience</li>
              <li>Preventing fraud and enforcing our terms of service</li>
              <li>Complying with legal obligations</li>
            </ul>

            <h2>4. Data Sharing and Disclosure</h2>
            <p>We may share your information in the following situations:</p>
            <ul>
              <li><strong>With Service Providers:</strong> We may share your information with third-party vendors who provide services on our behalf.</li>
              <li><strong>For Legal Compliance:</strong> We may disclose your information where required by law or to protect our rights.</li>
              <li><strong>With Your Consent:</strong> We may share your information with third parties when you have given us consent to do so.</li>
              <li><strong>Business Transfers:</strong> In connection with a merger, acquisition, or sale of assets, your information may be transferred.</li>
            </ul>

            <h2>5. Data Security</h2>
            <p>
              We implement appropriate security measures to protect your personal information. 
              However, no method of transmission over the internet or electronic storage is 100% secure. 
              We cannot guarantee absolute security of your data.
            </p>

            <h2>6. Your Rights</h2>
            <p>Depending on your location, you may have the following rights regarding your personal data:</p>
            <ul>
              <li>Access to your personal data</li>
              <li>Correction of inaccurate or incomplete information</li>
              <li>Deletion of your personal data</li>
              <li>Restriction of processing</li>
              <li>Data portability</li>
              <li>Objection to processing</li>
              <li>Withdrawal of consent</li>
            </ul>

            <h2>7. Children's Privacy</h2>
            <p>
              Our services are not intended for individuals under the age of 18. 
              We do not knowingly collect personal information from children under 18. 
              If we learn we have collected personal information from a child under 18, 
              we will delete this information.
            </p>

            <h2>8. International Data Transfers</h2>
            <p>
              Your information may be transferred to and processed in countries other than the one in which you reside. 
              These countries may have different data protection laws. 
              By using our services, you consent to this transfer.
            </p>

            <h2>9. Changes to This Privacy Policy</h2>
            <p>
              We may update this Privacy Policy from time to time. We will notify you of any changes by posting the 
              new Privacy Policy on this page and updating the "Last updated" date.
            </p>

            <h2>10. Contact Us</h2>
            <p>
              If you have any questions about this Privacy Policy, please contact us at:<br />
              Email: privacy@airdropverse.com
            </p>
          </CardContent>
        </Card>
      </div>
    </>
  );
}